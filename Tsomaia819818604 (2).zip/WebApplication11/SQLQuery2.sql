﻿Create DATABASE Web_DB
-- User Info
DROP TABLE IF EXISTS UserInfo;
CREATE TABLE UserInfo
(
  UserID INT NOT NULL PRIMARY KEY,
  UserName VARCHAR(30) NOT NULL,
  UserPass VARCHAR(30) NOT NULL,
  FirstName VARCHAR(30) NOT NULL,
  LastName VARCHAR(30) NOT NULL,
  Gender INT NOT NULL, 
  DOB DATE NOT NULL,
  RegistrationDate DATE NOT NULL, 
  Email VARCHAR(30)  NOT NULL

);

-- Categories 
DROP TABLE IF EXISTS Categories; 
CREATE TABLE Categories
(
  CategoryID INT NOT NULL PRIMARY KEY,
  Title VARCHAR(20)	NOT NULL
);


-- Posts 
DROP TABLE IF EXISTS Posts; 
CREATE TABLE Posts
(
  PostID INT NOT NULL PRIMARY KEY,
  UserID INT FOREIGN KEY REFERENCES UserInfo(UserID),
  CategoryID INT FOREIGN KEY REFERENCES Categories(CategoryID),
  PostTitle VARCHAR(20)	NOT NULL,
  Content VARCHAR(400) NOT NULL
);

-- Comments 
DROP TABLE IF EXISTS Comments; 
CREATE TABLE Comments
(
  CommentID INT PRIMARY KEY NOT NULL,
  PostID INT FOREIGN KEY REFERENCES Posts(PostID),
  UserID INT FOREIGN KEY REFERENCES UserInfo(UserID),
  comment VARCHAR(200) NOT NULL
);

