﻿using System;
using System.Collections.Generic;

namespace WebApplication11.Models
{
    public partial class Categories
    {
        public Categories()
        {
            Posts = new HashSet<Posts>();
        }

        public int CategoryId { get; set; }
        public string Title { get; set; }

        public ICollection<Posts> Posts { get; set; }
    }
}
