﻿using System;
using System.Collections.Generic;

namespace WebApplication11.Models
{
    public partial class UserInfo
    {
        public UserInfo()
        {
            Comments = new HashSet<Comments>();
            Posts = new HashSet<Posts>();
        }

        public int UserId { get; set; }
        public string UserName { get; set; }
        public string UserPass { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Gender { get; set; }
        public DateTime Dob { get; set; }
        public DateTime RegistrationDate { get; set; }
        public string Email { get; set; }

        public ICollection<Comments> Comments { get; set; }
        public ICollection<Posts> Posts { get; set; }
    }
}
