﻿using System;
using System.Collections.Generic;

namespace WebApplication11.Models
{
    public partial class Posts
    {
        public Posts()
        {
            Comments = new HashSet<Comments>();
        }

        public int PostId { get; set; }
        public int? UserId { get; set; }
        public int? CategoryId { get; set; }
        public string PostTitle { get; set; }
        public string Content { get; set; }

        public Categories Category { get; set; }
        public UserInfo User { get; set; }
        public ICollection<Comments> Comments { get; set; }
    }
}
